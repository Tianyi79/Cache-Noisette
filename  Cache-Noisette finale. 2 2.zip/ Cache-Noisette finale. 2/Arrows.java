import javax.swing.*;

import java.awt.*;

public class Arrows {

    /**
     * four buttons
     */
    public JButton arrowDown;

    public JButton arrowUp;

    public JButton arrowLeft;

    public JButton arrowRight;

    /**
     * This class create four arrow buttons.
     * Set up four arrows by the picture.class
     */
    public Arrows() {
        initArrows();
    }

    private void initArrows() {
        this.arrowDown = new JButton(new Picture("BigArrow的副本.png", 0));
        this.arrowUp = new JButton(new Picture("BigArrow的副本3.png", 0));
        this.arrowLeft = new JButton(new Picture("ArrowB.png", 0));
        this.arrowRight = new JButton(new Picture("Arrow的副本2.png", 0));

        this.arrowDown.setBorder(null);
        this.arrowUp.setBorder(null);
        this.arrowLeft.setBorder(null);
        this.arrowRight.setBorder(null);
    }

    /**
     * put four arrow buttons into the frame which set up in the main method.
     *
     * @param panel the required frame.
     */
    public void addArrow(JPanel panel) {
        panel.add(BorderLayout.SOUTH, this.arrowDown);
        panel.add(BorderLayout.NORTH, this.arrowUp);
        panel.add(BorderLayout.WEST, this.arrowLeft);
        panel.add(BorderLayout.EAST, this.arrowRight);
    }
}
