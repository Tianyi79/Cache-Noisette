/**
 * This class is for a grid inside the board. Containing all situations the grid will
 * show. Such as: empty grid, grid with hole, if squirrel on grids, if flower on grids.
 */
public class Grid {

    /**
     * default grid picture "Empty.png"
     */
    private Picture picture = new Picture("Empty.png", 0);

    /**
     * whether the grids are occupied by squirrels.
     * Default it as null(no squirrels).
     */
    private Squirrel squirrel = null;

    /**
     * If the grid has a hole.
     */
    private boolean isHole = false;

    /**
     * If the hole is filled with a hazel.
     */
    private boolean haveHazel = false;

    /**
     * If the grid has a flower.
     */
    private boolean isFlower = false;


    /**
     * None-parameter constructor.
     */
    public Grid() {

    }


    /**
     * Constructor
     *
     * @param picture the grid's picture.
     */
    public Grid(Picture picture) {
        this.picture = picture;
    }

    /**
     * Constructor.
     *
     * @param picture  the grid's picture.
     * @param isHole   true for is a hole, false for not a hole.
     * @param isFlower true for is a flower, false for not a flower.
     */
    public Grid(Picture picture, boolean isHole, boolean isFlower) {
        this.picture = picture;
        this.isHole = isHole;
        this.isFlower = isFlower;

    }

    /**
     * set the picture of a hole.
     *
     * @param picture
     */
    public void setPicture(Picture picture) {
        this.picture = picture;
    }

    /**
     * get the picture of the grid.
     *
     * @return
     */
    public Picture getPicture() {
        return picture;
    }

    /**
     * set a squirrel.
     *
     * @param squirrel
     */
    public void setSquirrel(Squirrel squirrel) {
        this.squirrel = squirrel;


    }


    /**
     * get the squirrel.
     *
     * @return if the grid contains a squirrel, then return that squirrel,
     * if not then return null.
     */
    public Squirrel getSquirrel() {
        return squirrel;
    }

    /**
     * use this method to judge whether it is a hole.
     *
     * @return true for is a hole, false for opposite.
     */
    public boolean isHole() {
        return isHole;
    }


    /**
     * judge whether the hazel fill the hole.
     *
     * @return true for yes，false for no.
     */
    public boolean isHaveHazel() {
        return haveHazel;
    }

    /**
     * set the whether there is a hazel in the hole.
     *
     * @param haveHazel true for yes，false for no.
     */
    public void setHaveHazel(boolean haveHazel) {
        this.haveHazel = haveHazel;
    }

    /**
     * get whether there is a flower on the hole.
     *
     * @return true for yes, fase for no.
     */
    public boolean isFlower() {
        return isFlower;
    }
}
