import javax.swing.*;

/**
 * This class creates a menu bar on the frame,
 * for player to choos the level "EASY","MEDIUM" and "HARD".
 */


public class initMenu {

    JMenuBar menuBar;

    JMenu levelMenu;

    JMenuItem elevelMenu;

    JMenuItem mlevelMenu;

    JMenuItem hlevelMenu;

    JMenuItem tlevelMenu;

    /**
     * Constructor.
     * Define the menu items "EASY" "MEDIUM" and "HARD".
     */
    public initMenu() {
        
        menuBar = new JMenuBar();
        levelMenu = new JMenu(" Level ");
        elevelMenu = new JMenuItem("EASY");
        mlevelMenu = new JMenuItem("MEDIUM");
        hlevelMenu = new JMenuItem("HARD");
        tlevelMenu = new JMenuItem("TRICKY");



    }

    /**
     * add all items inside the menu. And add the menu to the menubar.
     */

    public void menuSet() {
        levelMenu.add(elevelMenu);
        levelMenu.add(mlevelMenu);
        levelMenu.add(hlevelMenu);
        levelMenu.add(tlevelMenu);
        menuBar.add(levelMenu);
    }
}
