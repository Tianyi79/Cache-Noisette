/**
 * The easy level, one red squirrel and one grey squirrel.
 */
public class Easy {

    public Squirrel redSquirrel;

    public Squirrel greySquirrel;

    public Grid[][] grids = new Grid[4][4];

    /**
     * Constructor. Create a new instance of the easy level. By initializing
     * squirrel pieces and setting up grids.
     */
    public Easy() {
        redSquirrel = new Squirrel();
        //initializing squirrel pieces.
        setupSquirrel();
        //set the grids of the board.
        setUpGrids();


    }

    /**
     * initializing the squirrel pieces, assemble face, tail and flowers.
     */
    private void setupSquirrel() {
        //red squirrel.
        redSquirrel.setFacePic(new Picture("RedSquirrel1Nut.png", 270));
        redSquirrel.setFaceWithoutHazelPic("Red", 270);
        redSquirrel.setTailPic("Red", 270);
        int[] facep = { 1, 1 };
        redSquirrel.setFacePos(facep);
        int[] tailp = { 1, 2 };
        redSquirrel.setTailPos(tailp);
        redSquirrel.setHaveHazel(true);

        //grey squirrel.
        greySquirrel = new Squirrel();
        greySquirrel.setFacePic(new Picture("GreySquirrel1Nut.png", 0));
        greySquirrel.setTailPic("Grey", 0);
        greySquirrel.setFaceWithoutHazelPic("Grey", 0);
        int[] facepGrey = { 2, 2 };
        greySquirrel.setFacePos(facepGrey);
        int[] tailpGrey = { 3, 2 };
        greySquirrel.setTailPos(tailpGrey);
        greySquirrel.setHaveHazel(true);

    }

    /**
     * Set up the grids.
     */
    private void setUpGrids() {
        // put the hole or flower in particular grids.
        //and put the "empty" grid in other grids.
        grids[0][0] = new Grid();
        grids[0][1] = new Grid();
        if (grids[0][2] != null) {
            updateHole(grids[0][2]);
        } else {
            grids[0][2] = new Grid(new Picture("Hole.png", 0), true, false);
        }
        grids[0][3] = new Grid();
        if (grids[1][0] != null) {
            updateHole(grids[1][0]);
        } else {
            grids[1][0] = new Grid(new Picture("Hole.png", 0), true, false);
        }
        grids[1][1] = new Grid();
        grids[1][2] = new Grid();
        grids[1][3] = new Grid();
        grids[2][0] = new Grid();

        if (grids[2][1] != null) {
            updateHole(grids[2][1]);
        } else {
            grids[2][1] = new Grid(new Picture("Flower.png", 0), true, true);
        }
        grids[2][2] = new Grid();
        grids[2][3] = new Grid();
        grids[3][0] = new Grid();
        grids[3][1] = new Grid();
        grids[3][2] = new Grid();
        if (grids[3][3] != null) {
            updateHole(grids[3][3]);
        } else {
            grids[3][3] = new Grid(new Picture("Hole.png", 0), true, false);
        }

        //initializing no squirrels.
        for (int i = 0; i < 4; i++) {
            for (int y = 0; y < 4; y++) {
                grids[i][y].setSquirrel(null);
            }
        }

        grids[redSquirrel.getFacePos()[0]][redSquirrel.getFacePos()[1]].setPicture(redSquirrel.getFacePic());
        grids[redSquirrel.getFacePos()[0]][redSquirrel.getFacePos()[1]].setSquirrel(redSquirrel);
        grids[redSquirrel.getTailPos()[0]][redSquirrel.getTailPos()[1]].setSquirrel(redSquirrel);
        grids[redSquirrel.getTailPos()[0]][redSquirrel.getTailPos()[1]].setPicture(redSquirrel.getTailPic());


        grids[greySquirrel.getFacePos()[0]][greySquirrel.getFacePos()[1]].setPicture(greySquirrel.getFacePic());
        grids[greySquirrel.getFacePos()[0]][greySquirrel.getFacePos()[1]].setSquirrel(greySquirrel);
        grids[greySquirrel.getTailPos()[0]][greySquirrel.getTailPos()[1]].setSquirrel(greySquirrel);
        grids[greySquirrel.getTailPos()[0]][greySquirrel.getTailPos()[1]].setPicture(greySquirrel.getTailPic());

    }


    /**
     * Update the grids situation.
     *
     * @param grid new grids situation.
     */
    private void updateHole(Grid grid) {
        if (grid.isHaveHazel()) {
            grid.setPicture(new Picture("HoleNut.png", 0));
        } else {
            if (grid.isFlower()) {
                grid.setPicture(new Picture("Flower.png", 0));
            } else {
                grid.setPicture(new Picture("Hole.png", 0));
            }
        }

    }

    /**
     * get the 4X4 grids.
     *
     * @return the new situation of the grids.
     */
    public Grid[][] getGrids() {
        return grids;
    }

    /**
     * Move up the squirrel.
     *
     * @param squirrel selected squirrel.
     *
     * @return the new situation of the grid.
     */
    public Grid[][] moveUp(Squirrel squirrel) {

        if (squirrel != null) {

            System.out.println("move " + squirrel.getColor() + " squirrel up");
            int facePositionRow = squirrel.getFacePos()[0];
            int tailRow = squirrel.getTailPos()[0];
            System.out.println("facePosition Row:" + facePositionRow);
            if (facePositionRow > 0) {
                Grid borderGrid1 = grids[facePositionRow - 1][squirrel.getFacePos()[1]];
                Grid borderGrid2 = grids[tailRow - 1][squirrel.getTailPos()[1]];
                boolean isCanMove = false;
                if (squirrel == greySquirrel) {
                    isCanMove = canMove(borderGrid1);
                } else {
                    isCanMove = canMove(borderGrid1) && canMove(borderGrid2);
                }
                if (isCanMove) {
                    squirrel.getFacePos()[0] = facePositionRow - 1;
                    squirrel.getTailPos()[0] = tailRow - 1;
                    setUpGrids();
                    dropNut(squirrel);
                }
            }
        }

        return grids;
    }

    /**
     * Move down the squirrel.
     *
     * @param squirrel Selected squirrel.
     *
     * @return new situation of the grid.
     */
    public Grid[][] moveDown(Squirrel squirrel) {
        System.out.println("Demand: move down " + squirrel.getColor() + " squirrel:");
        if (squirrel != null) {
            int facePositionRow = squirrel.getFacePos()[0];
            int tailRow = squirrel.getTailPos()[0];
            System.out.println("facePositionRow:" + facePositionRow);
            if (squirrel == redSquirrel && facePositionRow < 3) {
                Grid borderGrid1 = grids[facePositionRow + 1][squirrel.getFacePos()[1]];
                Grid borderGrid2 = grids[tailRow + 1][squirrel.getTailPos()[1]];
                if (canMove(borderGrid1) && canMove(borderGrid2)) {
                    squirrel.getFacePos()[0] = facePositionRow + 1;
                    squirrel.getTailPos()[0] = tailRow + 1;
                    setUpGrids();
                    dropNut(squirrel);
                }
            } else if (squirrel == greySquirrel && tailRow < 3) {
                Grid borderGrid2 = grids[tailRow + 1][squirrel.getTailPos()[1]];
                if (canMove(borderGrid2)) {
                    squirrel.getFacePos()[0] = facePositionRow + 1;
                    squirrel.getTailPos()[0] = tailRow + 1;
                    setUpGrids();
                    dropNut(squirrel);
                }
            }
        }
        return grids;
    }


    /**
     * Move the squirrel left.
     *
     * @param squirrel selected squirrel.
     *
     * @return new situation of the grid.
     */
    public Grid[][] moveLeft(Squirrel squirrel) {

        if (squirrel != null) {
            System.out.println("Demand: move " + squirrel.getColor() + " squirrel left");
            int facePositionColumn = squirrel.getFacePos()[1];
            int tailColumn = squirrel.getTailPos()[1];
            if (facePositionColumn > 0) {

                int targetColumn1 = facePositionColumn - 1;
                int targetColumn2 = tailColumn - 1;

                Grid borderGrid1 = grids[squirrel.getFacePos()[0]][targetColumn1];
                Grid borderGrid2 = grids[squirrel.getTailPos()[0]][targetColumn2];
                boolean isCanMove = false;
                if (squirrel == redSquirrel) {
                    isCanMove = canMove(borderGrid1);
                } else {
                    isCanMove = canMove(borderGrid1) && canMove(borderGrid2);
                }
                if (isCanMove) {
                    squirrel.getFacePos()[1] = facePositionColumn - 1;
                    squirrel.getTailPos()[1] = tailColumn - 1;
                    setUpGrids();
                    dropNut(squirrel);
                }
            }
            System.out.println("facePositionColumn:" + facePositionColumn);
        }
        return grids;
    }


    /**
     * Move the squirrel to the right.
     *
     * @param squirrel selected squirrel.
     *
     * @return new situation of the grid.
     */
    public Grid[][] moveRight(Squirrel squirrel) {
        if (squirrel != null) {
            System.out.println("Demand move " + squirrel.getColor() + " squirrel right");
            int facePositionColumn = squirrel.getFacePos()[1];
            int tailColumn = squirrel.getTailPos()[1];
            System.out.println(" tailColumn: " + tailColumn);
            if (tailColumn < 3) {
                int targetColumn1 = facePositionColumn + 1;
                int targetColumn2 = tailColumn + 1;
                Grid borderGrid1 = grids[squirrel.getFacePos()[0]][targetColumn1];
                Grid borderGrid2 = grids[squirrel.getTailPos()[0]][targetColumn2];
                boolean isCanMove = false;
                if (squirrel == redSquirrel) {
                    isCanMove = canMove(borderGrid2);
                } else {
                    isCanMove = canMove(borderGrid1) && canMove(borderGrid2);
                }
                if (isCanMove) {
                    squirrel.getFacePos()[1] = facePositionColumn + 1;
                    squirrel.getTailPos()[1] = tailColumn + 1;
                    setUpGrids();
                    dropNut(squirrel);
                }
            }
        }
        return grids;
    }


    /**
     * drop the hazel in the grid with hole.
     *
     * @param squirrel squirrel with hazel and face on the hole.
     */
    private void dropNut(Squirrel squirrel) {
        if (squirrel.isHaveHazel()) {
            int[] pos = squirrel.getFacePos();
            Grid grid = grids[pos[0]][pos[1]];
            System.out.println(
                    "next target face location has hole?: " + grid.isHole() + ", Row: " + pos[0] + ", column: " + pos[1]);
            if (grid.isHole() && !grid.isHaveHazel()) {
                grid.setHaveHazel(true);
                squirrel.setHaveHazel(false);
                squirrel.setFacePic(squirrel.getFaceWithoutHazelPic());
                System.out.println(squirrel.getColor() + " squirrel drop Hazel");
            }

        }

    }

    /**
     * if any parts of the squirrel overlap other squirrel or flowers. The squirrel can not move.
     *
     * @param targetGrid the border of the squirrel.
     *
     * @return
     */
    private boolean canMove(Grid targetGrid) {
        System.out.println(
                "canMove borderGrid.getSquirrel: " + targetGrid.getSquirrel() + ", borderGrid.isFlower:" + targetGrid.isFlower());
        return targetGrid.getSquirrel() == null && !targetGrid.isFlower();
    }

    /**
     * if all hazels are put in the hole, game success.
     *
     * @return true for success, false for uncomplete.
     */
    public boolean succeed() {

        return !redSquirrel.isHaveHazel() && !greySquirrel.isHaveHazel();
    }


    /**
     * reset the game.
     */
    public void reset() {
        setupSquirrel();
        grids = null;
        grids = new Grid[4][4];
        setUpGrids();
    }

}