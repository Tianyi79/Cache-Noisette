/**
 * This class represents a medium level. Containing a red squirrel, black squirrel and a brown squirrel.
 */
public class Medium {

    public Squirrel blackSquirrel;

    public Squirrel brownSquirrel;

    public Squirrel redSquirrel;

    public Grid[][] grids = new Grid[4][4];

    /**
     * Constructor
     */
    public Medium() {
        blackSquirrel = new Squirrel();
        brownSquirrel = new Squirrel();
        redSquirrel = new Squirrel();
        //initializing the squirrel pieces.
        setupSquirrel();

        //setting up the grids.
        setUpGrids();
    }

    /**
     * initializing the squirrel pieces.
     */
    private void setupSquirrel() {

        //initialzing the position of blacksquirrel
        blackSquirrel.setFacePic(new Picture("BlackSquirrel1Nut.png", 180));
        blackSquirrel.setFaceWithoutHazelPic("Black", 180);
        blackSquirrel.setTailPic("Black", 180);
        int[] fp = { 1, 2 };
        blackSquirrel.setFacePos(fp);
        int[] tp = { 0, 2 };
        blackSquirrel.setTailPos(tp);
        blackSquirrel.setHaveHazel(true);
        int[] flowerPos = { 0, 1 };
        blackSquirrel.setFlowerPos(flowerPos);
        blackSquirrel.setFlowerPic(new Picture("SquirrelFlower.png", 0));


        //initializing the position of the brown squirrel.
        brownSquirrel.setFacePic(new Picture("BrownSquirrel1Nut.png", 180));
        brownSquirrel.setTailPic("Brown", 180);
        brownSquirrel.setFaceWithoutHazelPic("Brown", 180);
        int[] fpBrown = { 2, 3 };
        brownSquirrel.setFacePos(fpBrown);
        int[] tpBrown = { 1, 3 };
        brownSquirrel.setTailPos(tpBrown);
        brownSquirrel.setHaveHazel(true);
        int[] flowerPos1 = { 2, 2 };
        brownSquirrel.setFlowerPos(flowerPos1);
        brownSquirrel.setFlowerPic(new Picture("SquirrelFlower.png", 0));

        //initializing the position of the red squirrel.
        redSquirrel.setFacePic(new Picture("RedSquirrel1Nut.png", 90));
        redSquirrel.setFaceWithoutHazelPic("Red", 90);
        redSquirrel.setTailPic("Red", 90);
        int[] facep = { 1, 1 };
        redSquirrel.setFacePos(facep);
        int[] tailp = { 1, 0 };
        redSquirrel.setTailPos(tailp);
        redSquirrel.setHaveHazel(true);
    }

    /**
     * initializing the grids.
     */
    private void setUpGrids() {
        grids[0][0] = new Grid();
        grids[0][1] = new Grid();
        if (grids[0][2] != null) {
            updateHole(grids[0][2]);
        } else {
            grids[0][2] = new Grid(new Picture("Hole.png", 0), true, false);
        }
        grids[0][3] = new Grid();
        if (grids[1][0] != null) {
            updateHole(grids[1][0]);
        } else {
            grids[1][0] = new Grid(new Picture("Hole.png", 0), true, false);
        }
        grids[1][1] = new Grid();
        grids[1][2] = new Grid();
        grids[1][3] = new Grid();
        grids[2][0] = new Grid();

        if (grids[2][1] != null) {
            updateHole(grids[2][1]);
        } else {
            grids[2][1] = new Grid(new Picture("Hole.png", 0), true, false);
        }
        grids[2][2] = new Grid();
        grids[2][3] = new Grid();
        grids[3][0] = new Grid();
        grids[3][1] = new Grid();
        grids[3][2] = new Grid();
        if (grids[3][3] != null) {
            updateHole(grids[3][3]);
        } else {
            grids[3][3] = new Grid(new Picture("Hole.png", 0), true, false);
        }

        for (int i = 0; i < 4; i++) {
            for (int y = 0; y < 4; y++) {
                grids[i][y].setSquirrel(null);
            }
        }

        grids[blackSquirrel.getFacePos()[0]][blackSquirrel.getFacePos()[1]].setPicture(blackSquirrel.getFacePic());
        grids[blackSquirrel.getTailPos()[0]][blackSquirrel.getTailPos()[1]].setPicture(blackSquirrel.getTailPic());
        grids[blackSquirrel.getFlowerPos()[0]][blackSquirrel.getFlowerPos()[1]].setPicture(
                blackSquirrel.getFlowerPic());
        grids[blackSquirrel.getFacePos()[0]][blackSquirrel.getFacePos()[1]].setSquirrel(blackSquirrel);
        grids[blackSquirrel.getTailPos()[0]][blackSquirrel.getTailPos()[1]].setSquirrel(blackSquirrel);
        grids[blackSquirrel.getFlowerPos()[0]][blackSquirrel.getFlowerPos()[1]].setSquirrel(blackSquirrel);

        grids[brownSquirrel.getFacePos()[0]][brownSquirrel.getFacePos()[1]].setPicture(brownSquirrel.getFacePic());
        grids[brownSquirrel.getTailPos()[0]][brownSquirrel.getTailPos()[1]].setPicture(brownSquirrel.getTailPic());
        grids[brownSquirrel.getFlowerPos()[0]][brownSquirrel.getFlowerPos()[1]].setPicture(
                brownSquirrel.getFlowerPic());
        grids[brownSquirrel.getFacePos()[0]][brownSquirrel.getFacePos()[1]].setSquirrel(brownSquirrel);
        grids[brownSquirrel.getTailPos()[0]][brownSquirrel.getTailPos()[1]].setSquirrel(brownSquirrel);
        grids[brownSquirrel.getFlowerPos()[0]][brownSquirrel.getFlowerPos()[1]].setSquirrel(brownSquirrel);

        grids[redSquirrel.getFacePos()[0]][redSquirrel.getFacePos()[1]].setPicture(redSquirrel.getFacePic());
        grids[redSquirrel.getFacePos()[0]][redSquirrel.getFacePos()[1]].setSquirrel(redSquirrel);
        grids[redSquirrel.getTailPos()[0]][redSquirrel.getTailPos()[1]].setSquirrel(redSquirrel);
        grids[redSquirrel.getTailPos()[0]][redSquirrel.getTailPos()[1]].setPicture(redSquirrel.getTailPic());
    }

    /**
     * updating the hole's situation. Whether it is filled by fower or hazel.
     *
     * @param grid
     */
    private void updateHole(Grid grid) {
        if (grid.isHaveHazel()) {
            grid.setPicture(new Picture("HoleNut.png", 0));
        } else {
            if (grid.isFlower()) {
                grid.setPicture(new Picture("Flower.png", 0));
            } else {
                grid.setPicture(new Picture("Hole.png", 0));
            }
        }

    }

    /**
     * get all the grids.
     *
     * @return
     */
    public Grid[][] getGrids() {
        return grids;
    }

    /**
     * Move the squirrel up
     *
     * @param squirrel selected squirrel.
     *
     * @return new grids situation.
     */
    public Grid[][] moveUp(Squirrel squirrel) {
        System.out.println("Demand: move " + squirrel.getColor() + " squirrel up");
        if (squirrel != null) {
            int facePositionRow = squirrel.getFacePos()[0];
            int tailRow = squirrel.getTailPos()[0];
            int flowerRow = squirrel.getFlowerPos()[0];
            boolean isCanMove = false;
            System.out.println("facePositionY:" + facePositionRow);
            if (tailRow > 0) {

                if (squirrel == brownSquirrel || squirrel == blackSquirrel) {
                    Grid borderGrid2 = grids[tailRow - 1][squirrel.getTailPos()[1]];
                    Grid borderGrid3 = grids[flowerRow - 1][squirrel.getFlowerPos()[1]];
                    isCanMove = canMove(borderGrid2) && canMove(borderGrid3);

                } else if (squirrel == redSquirrel) {
                    Grid borderGrid1 = grids[facePositionRow - 1][squirrel.getFacePos()[1]];
                    Grid borderGrid2 = grids[tailRow - 1][squirrel.getTailPos()[1]];
                    isCanMove = canMove(borderGrid1) && canMove(borderGrid2);
                }
                if (isCanMove) {
                    squirrel.getFacePos()[0] = facePositionRow - 1;
                    squirrel.getTailPos()[0] = tailRow - 1;
                    squirrel.getFlowerPos()[0] = flowerRow - 1;
                    setUpGrids();
                    dropNut(squirrel);
                }
            }
        }

        return grids;
    }

    /**
     * move the squirrel down.
     *
     * @param squirrel selected squirrel.
     *
     * @return new grids situation.
     */
    public Grid[][] moveDown(Squirrel squirrel) {

        if (squirrel != null) {
            System.out.println("Demand: move " + squirrel.getColor() + " squirrel down");
            int facePositionRow = squirrel.getFacePos()[0];
            int tailRow = squirrel.getTailPos()[0];
            int flowerRow = squirrel.getFlowerPos()[0];
            boolean isCanMove = false;
            System.out.println("facePositionRow:" + facePositionRow);
            if (squirrel == blackSquirrel || squirrel == brownSquirrel) {
                Grid borderGrid1 = grids[facePositionRow + 1][squirrel.getFacePos()[1]];
                Grid borderGrid3 = grids[flowerRow + 1][squirrel.getFlowerPos()[1]];
                if (facePositionRow < 3) {
                    isCanMove = canMove(borderGrid1) && canMove(borderGrid3);
                }

            } else if (squirrel == redSquirrel) {
                if (tailRow < 3) {
                    Grid borderGrid2 = grids[tailRow + 1][squirrel.getTailPos()[1]];
                    Grid borderGrid1 = grids[facePositionRow + 1][squirrel.getFacePos()[1]];
                    isCanMove = canMove(borderGrid2) && canMove(borderGrid1);
                }
            }

            if (isCanMove) {
                squirrel.getFacePos()[0] = facePositionRow + 1;
                squirrel.getTailPos()[0] = tailRow + 1;
                squirrel.getFlowerPos()[0] = flowerRow + 1;
                setUpGrids();
                dropNut(squirrel);
            }
        }
        return grids;
    }


    /**
     * move the squirrel left.
     *
     * @param squirrel selected squirrel.
     *
     * @return new grid's situation.
     */
    public Grid[][] moveLeft(Squirrel squirrel) {

        if (squirrel != null) {
            System.out.println("Demand: move " + squirrel.getColor() + " squirrel left");
            int facePositionColumn = squirrel.getFacePos()[1];
            int tailColumn = squirrel.getTailPos()[1];
            int flowerColum = squirrel.getFlowerPos()[1];
            boolean isCanMove = false;

            if (flowerColum > 0 && squirrel == blackSquirrel) {
                Grid borderGrid1 = grids[squirrel.getFacePos()[0]][facePositionColumn - 1];
                Grid borderGrid3 = grids[squirrel.getFlowerPos()[0]][flowerColum - 1];
                isCanMove = canMove(borderGrid1) && canMove(borderGrid3);
                if (isCanMove) {
                    squirrel.getFacePos()[1] = facePositionColumn - 1;
                    squirrel.getTailPos()[1] = tailColumn - 1;
                    squirrel.getFlowerPos()[1] = flowerColum - 1;
                    setUpGrids();
                    dropNut(squirrel);
                }

            } else if (flowerColum > 0 && squirrel == brownSquirrel) {
                Grid borderGrid3 = grids[squirrel.getFlowerPos()[0]][flowerColum - 1];
                Grid borderGrid2 = grids[squirrel.getTailPos()[0]][tailColumn - 1];
                isCanMove = canMove(borderGrid3) && canMove(borderGrid2);
                if (isCanMove) {
                    squirrel.getFacePos()[1] = facePositionColumn - 1;
                    squirrel.getTailPos()[1] = tailColumn - 1;
                    squirrel.getFlowerPos()[1] = flowerColum - 1;
                    setUpGrids();
                    dropNut(squirrel);
                }
            } else if (tailColumn > 0 && squirrel == redSquirrel) {
                int targetColumn2 = tailColumn - 1;
                Grid borderGrid2 = grids[squirrel.getTailPos()[0]][targetColumn2];
                isCanMove = canMove(borderGrid2);
                if (isCanMove) {
                    squirrel.getFacePos()[1] = facePositionColumn - 1;
                    squirrel.getTailPos()[1] = tailColumn - 1;
                    setUpGrids();
                    dropNut(squirrel);
                }
            }


            System.out.println("facePositionColumn:" + facePositionColumn);
        }
        return grids;
    }


    /**
     * Move the squirrell right.
     *
     * @param squirrel selected squirrel.
     *
     * @return new grid's situation.
     */
    public Grid[][] moveRight(Squirrel squirrel) {
        if (squirrel != null) {
            System.out.println("Demand: move " + squirrel.getColor() + " squirrel right");
            int facePositionColumn = squirrel.getFacePos()[1];
            int tailColumn = squirrel.getTailPos()[1];
            int flowerColumn = squirrel.getFlowerPos()[1];
            System.out.println("tailColumn:" + tailColumn);
            int targetColumn1 = facePositionColumn + 1;
            int targetColumn2 = tailColumn + 1;
            boolean isCanMove = false;
            if (squirrel == blackSquirrel || squirrel == brownSquirrel) {
                if (tailColumn < 3) {
                    Grid borderGrid1 = grids[squirrel.getFacePos()[0]][targetColumn1];
                    Grid borderGrid2 = grids[squirrel.getTailPos()[0]][targetColumn2];
                    isCanMove = canMove(borderGrid1) && canMove(borderGrid2);
                }
                if (isCanMove) {
                    squirrel.getFacePos()[1] = facePositionColumn + 1;
                    squirrel.getTailPos()[1] = tailColumn + 1;
                    squirrel.getFlowerPos()[1] = flowerColumn + 1;
                    setUpGrids();
                    dropNut(squirrel);
                }

            } else if (facePositionColumn < 3 && squirrel == redSquirrel) {
                Grid borderGrid1 = grids[squirrel.getFacePos()[0]][targetColumn1];
                isCanMove = canMove(borderGrid1);
            }

            if (isCanMove) {
                squirrel.getFacePos()[1] = facePositionColumn + 1;
                squirrel.getTailPos()[1] = tailColumn + 1;
                setUpGrids();
                dropNut(squirrel);
            }
        }
        return grids;
    }


    /**
     * drop the hazel
     *
     * @param squirrel selected squirrel, put the hazel in the hole.
     */
    private void dropNut(Squirrel squirrel) {
        if (squirrel.isHaveHazel()) {
            int[] pos = squirrel.getFacePos();
            Grid grid = grids[pos[0]][pos[1]];
            System.out.println(
                    "next target face location has hole?: " + grid.isHole() + ",row: " + pos[0] + ",column:" + pos[1]);
            if (grid.isHole() && !grid.isHaveHazel()) {
                grid.setHaveHazel(true);
                squirrel.setHaveHazel(false);
                squirrel.setFacePic(squirrel.getFaceWithoutHazelPic());
                System.out.println(squirrel.getColor() + " squirrel drop Hazel");
            }

        }

    }

    /**
     * if any parts of the squirrel overlaps the other squirrels or flowers,
     * it cannot move
     *
     * @param targetGrid the border of the particular squirrel.
     *
     * @return
     */
    private boolean canMove(Grid borderGrid) {
        System.out.println(
                "canMove borderGrid.getSquirrel : " + borderGrid.getSquirrel() + ", borderGrid.isFlower: " + borderGrid.isFlower());
        return borderGrid.getSquirrel() == null && !borderGrid.isFlower();
    }

    /**
     * if all hazel are put in the holes, game success.
     *
     * @return
     */
    public boolean succeed() {
        return !blackSquirrel.isHaveHazel() && !brownSquirrel.isHaveHazel();
    }


    /**
     * reset the game.
     */
    public void reset() {
        setupSquirrel();
        grids = null;
        grids = new Grid[4][4];
        setUpGrids();
    }

}
