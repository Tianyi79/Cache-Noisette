import javax.swing.*;

import java.awt.*;
import java.text.DecimalFormat;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.*;

/**
 * This class include the main method. All Buttons and their action listeners.
 * Initializing the frame, the panel. Borderlayout and gridlayout.
 */
public class Roll {

    /**
     * The frame of the game.
     */
    private static JFrame frame;

    /**
     * panel which contains grids and arrow buttons.
     */
    private static JPanel panel;

    /**
     * which contains grid's panel and arrows.
     */
    private static JPanel mainPanel;

    /**
     * represent the easy level
     */
    private static final int EasyLevel = 0;

    /**
     * represent the medium level.
     */
    private static final int MediumLevel = 1;

    /**
     * represent the hard level.
     */
    private static final int HardLevel = 2;

     /**
     * represent the hard level.
     */
    private static final int trickyLevel = 3;

    /**
     * show the current level.
     */
    private static int currentLevel = EasyLevel;

    /**
     * The 4x4 grids.
     */
    static JButton[][] buttons = new JButton[4][4];

    /**
     * buttons in the 4x4 grids.
     */
    private static Grid[][] grids = new Grid[4][4];

    /**
     * the clicked button on the specific grid.
     */
    private static Grid SelectedGrid = new Grid();

    /**
     * an object of easy level.
     */
    private static Easy easyL = new Easy();

    /**
     * an object of medium level.
     */
    private static Medium mediumL = new Medium();

    /**
     * an object of hard level.
     */
    private static hard hardL = new hard();

    /**
     * an object of hard level.
     */
    private static tricky trickyL = new tricky();


    /**
     * default the tip into false.
     */
    private static boolean isShowTips = false;

    /**
     * the start time of excuting the game.
     */

    private static long start = System.nanoTime();

    /**
     * the time when complete particular level.
     */
    private static long end;

    /**
     * The duration of complete a level
     */

    private static double elapsed;

    /**
     * the timer notification when excute the game.
     */

    private static JPanel timing;


    public static void main(String[] args) {
        //the frame of the window.
        frame = new JFrame("cache Noisette");   //set up the frame.
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        //the border layout.
        BorderLayout borderLayout = new BorderLayout();
        mainPanel = new JPanel();
        mainPanel.setLayout(borderLayout);

        //combine gridlayout's panel with the main panel.
        panel = new JPanel();
        panel.setSize(600, 600);
        GridLayout layout = new GridLayout(4, 4);
        panel.setLayout(layout);
        Arrows mode = new Arrows();
        mode.addArrow(mainPanel);
        mainPanel.add(BorderLayout.CENTER, panel);
        arrowInitiater(mode);

        frame.setContentPane(mainPanel);
        initMenu(frame);
        // set the frame visible includes all objects above.
        frame.setVisible(true);

        JOptionPane.showMessageDialog(timing, "Are you ready?", "Time Starts!", JOptionPane.INFORMATION_MESSAGE);
        setUpGrids(panel);


        frame.pack();
    }

    private static void arrowInitiater(Arrows mode) {
        //setting arrows.
        mode.arrowUp.addActionListener(e -> {
            switch (currentLevel) {
                case 1 -> {
                    grids = mediumL.moveUp(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (mediumL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
                case 2 -> {
                    grids = hardL.moveUp(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (hardL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
                case 3 -> {
                    grids = trickyL.moveUp(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (trickyL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
                default -> {
                    grids = easyL.moveUp(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (easyL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
            }
            System.out.println("**moveUp confirmed**");
        });
        mode.arrowRight.addActionListener(e -> {
            switch (currentLevel) {
                case 1 -> {
                    grids = mediumL.moveRight(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (mediumL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
                case 2 -> {
                    grids = hardL.moveRight(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (hardL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
                case 3 -> {
                    grids = trickyL.moveRight(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (trickyL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
                default -> {
                    grids = easyL.moveRight(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (easyL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
            }
            System.out.println("**moveRight confirmed**");
        });
        mode.arrowDown.addActionListener(e -> {
            switch (currentLevel) {
                case 1 -> {
                    grids = mediumL.moveDown(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (mediumL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
                case 2 -> {
                    grids = hardL.moveDown(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (hardL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
                case 3 -> {
                    grids = trickyL.moveDown(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (trickyL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
                default -> {
                    grids = easyL.moveDown(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (easyL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
            }
            System.out.println("**moveDown confirmed**");
        });
        mode.arrowLeft.addActionListener(e -> {
            switch (currentLevel) {
                case 1 -> {
                    grids = mediumL.moveLeft(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (mediumL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
                case 2 -> {
                    grids = hardL.moveLeft(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (hardL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
                case 3 -> {
                    grids = trickyL.moveLeft(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (trickyL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
                default -> {
                    grids = easyL.moveLeft(SelectedGrid.getSquirrel());
                    updateGrid();
                    if (easyL.succeed()) {
                        allHazel(mainPanel);
                    }
                }
            }
            System.out.println("**moveLeft confirmed**");
        });
    }
    
    private static void initMenu(JFrame jf) {
        initMenu initMenu = new initMenu();
        initMenu.menuSet();
        System.out.println("**********EASY**********");

        initMenu.elevelMenu.addActionListener(e -> {
            isShowTips = false;
            start = System.nanoTime();
            currentLevel = EasyLevel;
            easyL.reset();
            grids = easyL.getGrids();
            updateGrid();
            System.out.println("**********EASY**********");
        });

        initMenu.mlevelMenu.addActionListener(e -> {
            isShowTips = false;
            start = System.nanoTime();
            currentLevel = MediumLevel;
            mediumL.reset();
            grids = mediumL.getGrids();
            updateGrid();
            System.out.println("**********MEDIUM**********");
        });

        initMenu.hlevelMenu.addActionListener(e -> {
            isShowTips = false;
            start = System.nanoTime();
            currentLevel = HardLevel;
            hardL.reset();
            grids = hardL.getGrids();
            updateGrid();
            System.out.println("**********HARD**********");
        });

        initMenu.tlevelMenu.addActionListener(e -> {
            isShowTips = false;
            start = System.nanoTime();
            currentLevel = trickyLevel;
            trickyL.reset();
            grids = trickyL.getGrids();
            updateGrid();
            System.out.println("**********HARD**********");
        });

        jf.setJMenuBar(initMenu.menuBar);
    }

    /**
     * set 4x4 grids，put it on the main panel.
     *
     * @param panel
     */
    private static void setUpGrids(JPanel panel) {
        if (currentLevel == EasyLevel) {
            grids = easyL.getGrids();
        } else if (currentLevel == MediumLevel) {
            grids = mediumL.getGrids();
        }

        // set up all 16 buttons for the board.
        setButtons buttonset = new setButtons();
        buttonset.set(buttons);
        buttonValidator(buttonset);

        for (int i = 0; i < 4; i++) {
            for (int y = 0; y < 4; y++) {
                buttons[i][y].setIcon(grids[i][y].getPicture());

                //Once execute, show current selected Squirrel
                System.out.print("Selected Squirrel:" + grids[i][y].getSquirrel() + "\t");

                panel.add(buttons[i][y]);
            }
            System.out.println();
        }
    }

    private static void buttonValidator(setButtons buttonset) {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                int buttonIndex = i * 4 + j;
                int finalI = i;
                int finalJ = j;
                buttonset.buttonList.get(buttonIndex).addActionListener(e -> {
                    SelectedGrid = grids[finalI][finalJ];
                    //Testing whether there is a squirrel on this grid.
                    System.out.printf("(%d,%d) current Location:%s Squirrel%n", finalI, finalJ,
                                      SelectedGrid.getSquirrel().getColor());
                });
            }
        }
    }

    /**
     * update the grid
     */
    private static void updateGrid() {
        for (int a = 0; a < 4; a++) {
            for (int b = 0; b < 4; b++) {
                JButton button = buttons[a][b];
                button.setIcon(grids[a][b].getPicture());
            }
        }
    }

    /**
     * Notification of putting all hazels in holes. And your time of completing a level.
     *
     * @param jPanel
     */
    static void allHazel(JPanel jPanel) {
        if (!isShowTips) {
            end = System.nanoTime();
            elapsed = (end - start) / 1_000_000_000.0;

            System.out.println("Time taken: " + elapsed);
            JOptionPane.showMessageDialog(jPanel, "Time taken " + new java.text.DecimalFormat("#.00").format(
                    elapsed) + " Seconds", "Mission Complete!!!", JOptionPane.INFORMATION_MESSAGE);
            isShowTips = true;
        }
    }
}
 
     
    
    
