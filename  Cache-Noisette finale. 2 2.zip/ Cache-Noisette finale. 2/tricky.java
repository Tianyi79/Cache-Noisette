 /**
 * This class represents the tricky level, which contains a red squirrel, a grey squirrel
 * brown squirrel and a black squirrel.
 */

 public class tricky{

    public Squirrel redSquirrel;
    public Squirrel greySquirrel;
    public Squirrel brownSquirrel;
    public Squirrel blackSquirrel;
    public Grid[][] grids = new Grid [4][4];

    

     /**
     * a constructor for creating 4 squirrels and setting up the grids.
     */
    public tricky(){
    
        redSquirrel = new Squirrel();
        greySquirrel = new Squirrel();
        blackSquirrel = new Squirrel();
        brownSquirrel = new Squirrel();

        setSquirrel();

        setUpGrids();

    }
    
    /**
     * default the squirrels' information.
     */
    private void setSquirrel(){

        //initializing the black squirrel.
        blackSquirrel.setFacePic(new Picture("BlackSquirrel1Nut.png", 180));
        blackSquirrel.setFaceWithoutHazelPic("Black", 180);
        blackSquirrel.setTailPic("Black", 180);
        int[] fp = {3, 1};
        blackSquirrel.setFacePos(fp);
        int[] tp = {2, 1};
        blackSquirrel.setTailPos(tp);
        blackSquirrel.setHaveHazel(true);
        int[] flowerPos = {2,0};
        blackSquirrel.setFlowerPos(flowerPos);
        blackSquirrel.setFlowerPic(new Picture("SquirrelFlower.png", 0));

         //initializing the red squirrel.
         redSquirrel.setFacePic(new Picture("RedSquirrel1Nut.png", 180));
         redSquirrel.setFaceWithoutHazelPic("Red", 180);
         redSquirrel.setTailPic("Red", 180);
         int[] facep = {2, 2};
         redSquirrel.setFacePos(facep);
         int[] tailp = {1, 2};
         redSquirrel.setTailPos(tailp);
         redSquirrel.setHaveHazel(true);

         //initializing the grey squirrel. 
        greySquirrel.setFacePic(new Picture("GreySquirrel1Nut.png", 90));
        greySquirrel.setFaceWithoutHazelPic("Grey", 90);
        greySquirrel.setTailPic("Grey", 90);
        int[] facep2 = {0, 1};
        greySquirrel.setFacePos(facep2);
        int[] tailp2 = {0, 0};
        greySquirrel.setTailPos(tailp2);
        greySquirrel.setHaveHazel(true);

         //initializing the brown squirrel.
         brownSquirrel.setFacePic(new Picture("BrownSquirrel1Nut.png", 90));
         brownSquirrel.setFaceWithoutHazelPic("Brown", 90);
         brownSquirrel.setTailPic("Brown", 90);
         int[] facep3 = {0, 3};
         brownSquirrel.setFacePos(facep3);
         int[] tailp3 = {0, 2};
         brownSquirrel.setTailPos(tailp3);
         brownSquirrel.setHaveHazel(true);
         int[] flowerPos3 = {1,3};
         brownSquirrel.setFlowerPos(flowerPos3);
         brownSquirrel.setFlowerPic(new Picture("SquirrelFlower.png", 0));


    }
    
    /**
     * Initializing the grids. 
     */
    public void setUpGrids(){
    grids[0][0] = new Grid();
        grids[0][1] = new Grid();
        if (grids[0][2] != null) {
            updateHole(grids[0][2]);
        } else {
            grids[0][2] = new Grid(new Picture("Hole.png", 0), true, false);
        }
        grids[0][3] = new Grid();
        if (grids[1][0] != null) {
            updateHole(grids[1][0]);
        } else {
            grids[1][0] = new Grid(new Picture("Hole.png", 0), true, false);
        }
        grids[1][1] = new Grid();
        grids[1][2] = new Grid();
        grids[1][3] = new Grid();
        grids[2][0] = new Grid();

        if (grids[2][1] != null) {
            updateHole(grids[2][1]);
        } else {
            grids[2][1] = new Grid(new Picture("Hole.png", 0), true, false);
        }
        grids[2][2] = new Grid();
        grids[2][3] = new Grid();
        grids[3][0] = new Grid();
        grids[3][1] = new Grid();
        grids[3][2] = new Grid();
        if (grids[3][3] != null) {
            updateHole(grids[3][3]);
        } else {
            grids[3][3] = new Grid(new Picture("Hole.png", 0), true, false);
        }
        


        for (int i = 0; i < 4; i++) {
            for (int y = 0; y < 4; y++) {
                grids[i][y].setSquirrel(null);
            }
        }

        grids[blackSquirrel.getFacePos()[0]][blackSquirrel.getFacePos()[1]].setPicture(blackSquirrel.getFacePic());
        grids[blackSquirrel.getTailPos()[0]][blackSquirrel.getTailPos()[1]].setPicture(blackSquirrel.getTailPic());
        grids[blackSquirrel.getFlowerPos()[0]][blackSquirrel.getFlowerPos()[1]].setPicture(blackSquirrel.getFlowerPic());
        grids[blackSquirrel.getFacePos()[0]][blackSquirrel.getFacePos()[1]].setSquirrel(blackSquirrel);
        grids[blackSquirrel.getTailPos()[0]][blackSquirrel.getTailPos()[1]].setSquirrel(blackSquirrel);
        grids[blackSquirrel.getFlowerPos()[0]][blackSquirrel.getFlowerPos()[1]].setSquirrel(blackSquirrel);

        grids[brownSquirrel.getFacePos()[0]][brownSquirrel.getFacePos()[1]].setPicture(brownSquirrel.getFacePic());
        grids[brownSquirrel.getTailPos()[0]][brownSquirrel.getTailPos()[1]].setPicture(brownSquirrel.getTailPic());
        grids[brownSquirrel.getFlowerPos()[0]][brownSquirrel.getFlowerPos()[1]].setPicture(brownSquirrel.getFlowerPic());
        grids[brownSquirrel.getFacePos()[0]][brownSquirrel.getFacePos()[1]].setSquirrel(brownSquirrel);
        grids[brownSquirrel.getTailPos()[0]][brownSquirrel.getTailPos()[1]].setSquirrel(brownSquirrel);
        grids[brownSquirrel.getFlowerPos()[0]][brownSquirrel.getFlowerPos()[1]].setSquirrel(brownSquirrel);

        grids[redSquirrel.getFacePos()[0]][redSquirrel.getFacePos()[1]].setPicture(redSquirrel.getFacePic());
        grids[redSquirrel.getFacePos()[0]][redSquirrel.getFacePos()[1]].setSquirrel(redSquirrel);
        grids[redSquirrel.getTailPos()[0]][redSquirrel.getTailPos()[1]].setSquirrel(redSquirrel);
        grids[redSquirrel.getTailPos()[0]][redSquirrel.getTailPos()[1]].setPicture(redSquirrel.getTailPic());
  
  
        grids[greySquirrel.getFacePos()[0]][greySquirrel.getFacePos()[1]].setPicture(greySquirrel.getFacePic());
        grids[greySquirrel.getFacePos()[0]][greySquirrel.getFacePos()[1]].setSquirrel(greySquirrel);
        grids[greySquirrel.getTailPos()[0]][greySquirrel.getTailPos()[1]].setSquirrel(greySquirrel);
        grids[greySquirrel.getTailPos()[0]][greySquirrel.getTailPos()[1]].setPicture(greySquirrel.getTailPic());
  

    }

    
     /**
     * Updating the situation of the hole. Whether it is filleg by flower, nuts or not.
     * @param grid
     */
    private void updateHole(Grid grid) {
        if (grid.isHaveHazel()) {
            grid.setPicture(new Picture("HoleNut.png", 0));
        } else {
            if (grid.isFlower()) {
                grid.setPicture(new Picture("Flower.png", 0));
            } else {
                grid.setPicture(new Picture("Hole.png", 0));
            }
        }
        
    }

     /**
     * get the grids.
     * @return
     */
    public Grid[][] getGrids() {
        return grids;
    }

    /**
     * Move the selected squirrel up.
     * @param squirrel selected suirrel.
     * @return new grids' situation.
     */

    public Grid[][] moveUp(Squirrel squirrel) {
        
        if (squirrel != null) {
            System.out.println("move " + squirrel.getColor() + " squirrel up");
            int facePositionRow = squirrel.getFacePos()[0];
            int tailRow = squirrel.getTailPos()[0];
            int flowerRow = squirrel.getFlowerPos()[0];
            System.out.println("facePositionY:" + facePositionRow);
        if(tailRow >0)    
        {
            if(squirrel == blackSquirrel||squirrel == brownSquirrel)
            {
                
                    Grid borderGrid1 = grids[facePositionRow - 1][squirrel.getFacePos()[1]];
                    Grid borderGrid2 = grids[tailRow - 1][squirrel.getTailPos()[1]];
                    Grid borderGrid3 = grids[flowerRow - 1][squirrel.getFlowerPos()[1]];
                    boolean isCanMove = false;

                    if(squirrel == blackSquirrel)
                    {
                        isCanMove = canMove(borderGrid3) && canMove(borderGrid2);

                    }else{
                        isCanMove = canMove(borderGrid1) && canMove(borderGrid2);
                    }
                    
                  
                    if (isCanMove) {
                        squirrel.getFacePos()[0] = facePositionRow - 1;
                        squirrel.getTailPos()[0] = tailRow - 1;
                        squirrel.getFlowerPos()[0] = flowerRow - 1;
                        setUpGrids();
                        dropNut(squirrel);
                    }
                
            }
            else if (squirrel == greySquirrel || squirrel == redSquirrel)
            {
                Grid borderGrid2 = grids[tailRow - 1][squirrel.getTailPos()[1]];
                Grid borderGrid1 = grids[facePositionRow - 1][squirrel.getFacePos()[1]];
                boolean isCanMove = false;

                if(squirrel == redSquirrel)
                {
                    isCanMove = canMove(borderGrid2);  

                }else {
                    isCanMove = canMove(borderGrid2) && canMove(borderGrid1);
                }
                
              if (isCanMove) {
                    squirrel.getFacePos()[0] = facePositionRow - 1;
                    squirrel.getTailPos()[0] = tailRow - 1;
                    setUpGrids();
                    dropNut(squirrel);
                }  
            
            }
        }
        }
                
    

        return grids;
    }

     /**
     * Move the selected squirrel down.
     * @param squirrel the selected squirrel.
     * @return 
     */
    public Grid[][] moveDown(Squirrel squirrel) {
         
        if (squirrel != null) {
            System.out.println("move " + squirrel.getColor() + " squirrel down");
            int facePositionRow = squirrel.getFacePos()[0];
            int tailRow = squirrel.getTailPos()[0];
            int flowerRow = squirrel.getFlowerPos()[0];
            boolean isCanMove = false;
            System.out.println("facePositionRow: " + facePositionRow);
            if(squirrel == redSquirrel||squirrel == greySquirrel)
            {
                if (facePositionRow < 3) {
                    Grid borderGrid1 = grids[facePositionRow + 1][squirrel.getFacePos()[1]];
                    Grid borderGrid2 = grids[tailRow + 1][squirrel.getTailPos()[1]];
                    isCanMove = false;
                    if (squirrel == redSquirrel) {
                        isCanMove = canMove(borderGrid1);
                    } else {
                        isCanMove = canMove(borderGrid1) && canMove(borderGrid2);
                    }
                    if (isCanMove) {
                        squirrel.getFacePos()[0] = facePositionRow + 1;
                        squirrel.getTailPos()[0] = tailRow + 1;
                        squirrel.getFlowerPos()[0] = flowerRow + 1;
                        setUpGrids();
                        dropNut(squirrel);
                    }
                }
            }
            else if (squirrel == blackSquirrel || squirrel == brownSquirrel){
             if (tailRow < 3)
             {
                Grid borderGrid1 = grids[facePositionRow + 1][squirrel.getFacePos()[1]];
                Grid borderGrid2 = grids[tailRow + 1][squirrel.getTailPos()[1]];
                Grid borderGrid3 = grids[flowerRow + 1][squirrel.getFlowerPos()[1]];
                isCanMove = canMove(borderGrid1) && canMove(borderGrid3);
                if(squirrel == blackSquirrel)
                {
                    isCanMove = canMove(borderGrid1) && canMove(borderGrid3);

                }else{
                    
                    isCanMove = canMove(borderGrid2) && canMove(borderGrid3);
                }
             }
            if (isCanMove) {
                squirrel.getFacePos()[0] = facePositionRow + 1;
                squirrel.getTailPos()[0] = tailRow + 1;
                squirrel.getFlowerPos()[0] = flowerRow + 1;
                setUpGrids();
                dropNut(squirrel);
            }
        }
    }
        return grids;
    }
    
     /**
     * Move the selected squirrel to the left.
     * @param squirrel selected squirrel.
     * @return the grids.
     */
    public Grid[][] moveLeft(Squirrel squirrel) {

        if (squirrel != null) {
            System.out.println("move " + squirrel.getColor() + " squirrel left");
            int facePositionColumn = squirrel.getFacePos()[1];
            int tailColumn = squirrel.getTailPos()[1];
            int flowerColum = squirrel.getFlowerPos()[1];
            boolean isCanMove = false;
            if(squirrel== redSquirrel || squirrel == greySquirrel)
            {
                if (facePositionColumn > 0) {
                    Grid borderGrid1 = grids[squirrel.getFacePos()[0]][facePositionColumn - 1];
                    Grid borderGrid2 = grids[squirrel.getTailPos()[0]][tailColumn - 1];      
                    if (squirrel == greySquirrel) {
                        isCanMove = canMove(borderGrid2);
                    } else {
                        isCanMove = canMove(borderGrid1) && canMove(borderGrid2);
                    }
                }
                System.out.println("facePositionColumn:" + facePositionColumn);
            
        } else if(squirrel == blackSquirrel||squirrel == brownSquirrel)
        {
            if (flowerColum > 0) {

                Grid borderGrid1 = grids[squirrel.getFacePos()[0]][facePositionColumn - 1];
                Grid borderGrid2 = grids[squirrel.getTailPos()[0]][tailColumn - 1];
                Grid borderGrid3 = grids[squirrel.getFlowerPos()[0]][flowerColum - 1];
                isCanMove = canMove(borderGrid1) && canMove(borderGrid3);
                if (squirrel == blackSquirrel)
                {
                    isCanMove = canMove(borderGrid3) && canMove(borderGrid1);
                }
                else  
                {
                    isCanMove = canMove(borderGrid3) && canMove(borderGrid2);
                }

            }  
            System.out.println("facePositionColumn:" + facePositionColumn);
        }
        if (isCanMove) {
                squirrel.getFacePos()[1] = facePositionColumn - 1;
                squirrel.getTailPos()[1] = tailColumn - 1;
                squirrel.getFlowerPos()[1] = flowerColum - 1;
                setUpGrids();
                dropNut(squirrel);
            }
    }
        return grids;
    }
    
     /**
     * Move the selected squirrel to the right.
     * @param squirrel selected squirrel
     * @return
     */
    public Grid[][] moveRight(Squirrel squirrel) {
        if (squirrel != null) {
            System.out.println("move " + squirrel.getColor() + " squirrel right");
            int facePositionColumn = squirrel.getFacePos()[1];
            int tailColumn = squirrel.getTailPos()[1];
            int flowerColumn = squirrel.getFlowerPos()[1];
            System.out.println("tailColumn:" + tailColumn);
            boolean isCanMove = false;
            if (tailColumn < 3) {
            Grid borderGrid1 = grids[squirrel.getFacePos()[0]][facePositionColumn + 1];
            Grid borderGrid2 = grids[squirrel.getTailPos()[0]][tailColumn + 1];
            Grid borderGrid3 = grids[squirrel.getFlowerPos()[0]][flowerColumn + 1];
            if (squirrel == redSquirrel || squirrel == greySquirrel ) 
            {    
                if(squirrel == redSquirrel)
                {
                  isCanMove = canMove(borderGrid1) && canMove(borderGrid2); 
                }else{
                    isCanMove = canMove(borderGrid1);
                }
                if (isCanMove) 
                {
                 squirrel.getFacePos()[1] = facePositionColumn + 1;
                 squirrel.getTailPos()[1] = tailColumn + 1;
                 setUpGrids();
                 dropNut(squirrel);       
                }
            }
            else if(squirrel == brownSquirrel || squirrel == blackSquirrel)
            {    
                if(squirrel == brownSquirrel)
                {
                   isCanMove = canMove(borderGrid1) && canMove(borderGrid3); 

                } else {
                    isCanMove = canMove(borderGrid1) && canMove(borderGrid2) ; 
                }
                 
            
            if (isCanMove) 
            {
                 squirrel.getFacePos()[1] = facePositionColumn + 1;
                 squirrel.getTailPos()[1] = tailColumn + 1;
                 squirrel.getFlowerPos()[1] = flowerColumn + 1;
                 setUpGrids();
                 dropNut(squirrel);       
            }
            }
                
            }
        
        }
        return grids;
    }

    /**
     * Drop the nut.
     * @param squirrel selected squirrel.
     */

    private void dropNut(Squirrel squirrel) {
        if (squirrel.isHaveHazel()) {
            int[] pos = squirrel.getFacePos();
            Grid grid = grids[pos[0]][pos[1]];
            System.out.println("next target face location has hole?: " + grid.isHole() + ",row: " + pos[0] + ",column: " + pos[1]);
            if (grid.isHole() && !grid.isHaveHazel()) {
                grid.setHaveHazel(true);
                squirrel.setHaveHazel(false);
                squirrel.setFacePic(squirrel.getFaceWithoutHazelPic());
                System.out.println(squirrel.getColor()+ " squirrel drop Hazel");
            }

        }

    }

    /**
     * judge whether the squirrel can move, when overlap squirrel or flowers squirrel cannot move.
     * @param targetGrid 
     * @return 
     */
    private boolean canMove(Grid borderGrid) {
        System.out.println("canMove borderGrid.getSquirrel : " + borderGrid.getSquirrel() + ", borderGrid.isFlower: " + borderGrid.isFlower());
        return borderGrid.getSquirrel() == null && !borderGrid.isFlower();
    }

    /**
     * success when all squirrels put hazel inthe holes.
     * @return
     */
    public boolean succeed() {
        return !blackSquirrel.isHaveHazel() && !brownSquirrel.isHaveHazel() && !redSquirrel.isHaveHazel() && !greySquirrel.isHaveHazel();
    }


    /**
     * reset the game.
     */
    public void reset() {
        setSquirrel();
        grids = null;
        grids = new Grid[4][4];
        setUpGrids();
    }

}

    


 