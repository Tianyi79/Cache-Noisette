

/**
 * This class if for defining a squirrel, set/get the body picture, set/get the squirrel position.
 */
public class Squirrel {

    private Picture face;
    
    private Picture faceWithoutHazel;
    
    private Picture tail;

    private Picture flower;

    private int facePosition[] = { 0, 0 };

    private int tailPosition[] = { 0, 0 };

    private int flowerPosition[] = { 0, 0 };

    private boolean haveHazel;

    private String color;


    /**
     * get the face picture.
     *
     * @return
     */
    public Picture getFacePic() {
        return face;
    }

    /**
     * set the face picture of the squirrel
     *
     * @param face
     */
    public void setFacePic(Picture face) {
        this.face = face;
    }

    /**
     * get the tail's picture.
     *
     * @return
     */
    public Picture getTailPic() {
        return tail;
    }

    /**
     * set the tail's picture.
     *
     * @param color
     * @param r
     */
    public void setTailPic(String color, int r) {
        this.tail = new Picture(color + "Squirrel2.png", r);
        this.color = color;
    }

    /**
     * get the color of the specific squirrel.
     *
     * @return the color.
     */
    public String getColor() {
        return this.color;
    }

    /**
     * get the picture of the flower.
     *
     * @return
     */
    public Picture getFlowerPic() {
        return flower;
    }

    /**
     * set the picture of the flower.
     *
     * @param flower
     */
    public void setFlowerPic(Picture flower) {
        this.flower = flower;
    }

    /**
     * set the position of squirrel's face.
     *
     * @param facePosition
     */
    public void setFacePos(int[] facePosition) {
        this.facePosition = facePosition;
    }


    /**
     * get the face position.
     *
     * @return return an arrey which contains 2 indexes，for example：[a][b] means
     * the face locates in the (a-1)th row, (b-1) column.
     */
    public int[] getFacePos() {
        return facePosition;
    }


    /**
     * get the squirrel's tail's position.
     *
     * @return return an array with 2 indexes, for example: [a][b] means
     * the tail locates in the (a-1)th row, (b-1)th column.
     */
    public int[] getTailPos() {
        return tailPosition;
    }

    /**
     * set the position of squirrel's tail.
     *
     * @param tailPosition
     */
    public void setTailPos(int[] tailPosition) {
        this.tailPosition = tailPosition;
    }

    /**
     * get the flower's position.
     *
     * @return return an array with 2 indexes, for example: [a][b] means
     * the flower locates in the (a-1)th row, (b-1)th column.
     */
    public int[] getFlowerPos() {
        return flowerPosition;
    }

    /**
     * set the position of the flower.
     *
     * @param flowerPosition
     */
    public void setFlowerPos(int[] flowerPosition) {
        this.flowerPosition = flowerPosition;
    }

    /**
     * set whether the squirrel have hazels.
     *
     * @param haveHazel true means squirrel have not put the hazel inside the hole.
     *                  false means the squirrel have put it in the hole.
     */
    public void setHaveHazel(boolean haveHazel) {
        this.haveHazel = haveHazel;
    }

    /**
     * get the the situation of squirrel still holding the hazel.
     *
     * @return true means still holding hazel, false means in the hole.
     */
    public boolean isHaveHazel() {
        return haveHazel;
    }

    /**
     * get the face icon without hazel.
     *
     * @return
     */
    public Picture getFaceWithoutHazelPic() {
        return faceWithoutHazel;
    }

    /**
     * set the face icon without hazel once putting the hazel in the hole.
     *
     * @param color
     * @param b
     */
    public void setFaceWithoutHazelPic(String color, int b) {


        this.faceWithoutHazel = new Picture(color + "Squirrel1.png", b);
    }
}
   
