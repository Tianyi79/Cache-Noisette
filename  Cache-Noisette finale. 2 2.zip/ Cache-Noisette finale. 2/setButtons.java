import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

/**
 * This class set one of the 16 buttons on each grid.
 */
public class setButtons {

    public JButton button1;

    public JButton button2;

    public JButton button3;

    public JButton button4;

    public JButton button5;

    public JButton button6;

    public JButton button7;

    public JButton button8;

    public JButton button9;

    public JButton button10;

    public JButton button11;

    public JButton button12;

    public JButton button13;

    public JButton button14;

    public JButton button15;

    public JButton button16;

    public List<JButton> buttonList = new ArrayList<>();

    /**
     * Constructor.
     */
    public setButtons() {
        this.button1 = new JButton();
        this.button2 = new JButton();
        this.button3 = new JButton();
        this.button4 = new JButton();
        this.button5 = new JButton();
        this.button6 = new JButton();
        this.button7 = new JButton();
        this.button8 = new JButton();
        this.button9 = new JButton();
        this.button10 = new JButton();
        this.button11 = new JButton();
        this.button12 = new JButton();
        this.button13 = new JButton();
        this.button14 = new JButton();
        this.button15 = new JButton();
        this.button16 = new JButton();

        Field[] fields = this.getClass().getFields();
        try {
            for (Field field : fields) {
                if (field.getType() == JButton.class) {
                    buttonList.add((JButton) field.get(this));
                }
            }
        } catch (Exception e) {
            System.out.println("System error");
        }
    }

    /**
     * Buttons with array are buttons created in the main method,
     * which are corresponds to the buttons in the instance.
     *
     * @param buttons button array created in main method.
     */

    public void set(JButton[][] buttons) {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                buttons[i][j] = this.buttonList.get(i * 4 + j);
            }
        }
    }
}
